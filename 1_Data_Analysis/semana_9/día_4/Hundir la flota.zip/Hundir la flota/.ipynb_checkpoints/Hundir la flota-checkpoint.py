# -*- coding: utf-8 -*-
"""
Created on Sat Jun 20 12:26:19 2020

@author: Ruben
"""

import numpy as np
# imports random module 
import random 
import copy

# variables taulell_o taulell_J
# Listas 10x10 de enteros

# Devuelve un tablero con las filas y columnas indicadas por medida. 
# Función con la que inicializamos las variables taulell_J y taulell_O llenándolas de ceros. 
def crear_taulell(mida) :
    
    nlista = []
    for i in range (mida):
        nlista.append([0] * mida)
    
    return nlista
    
# Función que visualiza el contenido de un tablero por cconsola
#Recibe como argumento un tablero y una variable booleana barcos. 
def visualitza_taulell(taulell, vaixells):
    
        taulell_aux=copy.deepcopy(taulell)

        
        if(vaixells==True):
            
            for i in range(0,len(taulell_aux)):
                for j in range(0,len(taulell_aux)):
                    if(taulell_aux[i][j]==1):
                        taulell_aux[i][j]='#'
                    elif(taulell_aux[i][j]==2):
                        taulell_aux[i][j]='.'
                    elif(taulell_aux[i][j]==3):
                        taulell_aux[i][j]='X'
                    else:
                        taulell_aux[i][j]=' '
            print(taulell_aux)
        else:
            
            for i in range(0,len(taulell_aux)):
                for j in range(0,len(taulell_aux)):

                    if(taulell_aux[i][j]==2):
                        taulell_aux[i][j]='.'
                    elif(taulell_aux[i][j]==3):
                        taulell_aux[i][j]='X'
                    else:
                        taulell_aux[i][j]=' '
            print(taulell_aux)

def demana_jugada ():
    res = False
    while True:
        print('Dame la siguiente fila entre: 0-10')
        fila=input()
        
        try:
            fila = int(fila)
        except ValueError:
            print ('Número valido, por favor')
            continue
        if 0 <= fila <= 9:
            res=True
        else:
            print ('Rango inválido: 0-9')
        if((res==True)):
            
            print('Dame la siguiente columna entre: ABCDEFGHIJ')
            columna=input()
            
            try:
                columna = str(columna)
            except ValueError:
                print ('Letra valida, por favor')
                continue
            if (columna in 'ABCDEFGHIJ'):
                break
            else:
                print ('Rango inválido: ABCDEFGHIJ')
            
        
    return fila,columna
    
def omplir_taulell_jugador (taulell):

        iteracion=0
############    Cambiar por 30
        while((iteracion<6) ):
        
            #Pedimos al jugador que nos de la fila y columna
            fila,columna=demana_jugada()
            
            #transformamos la letra de la columna en número
            int_columna=ord(columna)-65
            int_columna=int(int_columna)
            fila=int(fila)
            
            #Si se encuentran en los limites del tablero
            if((fila in range(0,len(taulell)-1)) & (int_columna in range(0,len(taulell)-1))):
                
                if(taulell[fila][int_columna]==0):
                     taulell[fila][int_columna]=1
                     iteracion=iteracion+1
                else:
                    print('Casilla ya rellena')
        return taulell
    

# Función que pone los buques del ordenador en el tablero al inicio del juego.
def omplir_taulell_ordinador (taulell, intents) :
    
    i=0
    #tamaño de barcos: 2 1x4; 3 1x3; 3 1x2; 1 1x5
    fila_in=False
    orientacion=bool(random.getrandbits(1))
    # El primer barco se pone aleatoriamente en el tablero y empezamos con el más grande
    while(fila_in==False | i <= intents):
         fila=random.randint(0,len(taulell)-1)
         columna=random.randint(0,len(taulell)-1)
         i=i+1
         #orientacion= true --> Filas
         if(orientacion==True):
             
             if(fila+5 in range(0,len(taulell)-1)):
                 fila_in=True
                 taulell[fila][columna]=1
                 taulell[fila+1][columna]=1
                 taulell[fila+2][columna]=1
                 taulell[fila+3][columna]=1
                 taulell[fila+4][columna]=1
         else:
             
            if(columna+5 in range(0,len(taulell)-1)):
                 fila_in=True
                 taulell[fila][columna]=1
                 taulell[fila][columna+1]=1
                 taulell[fila][columna+2]=1
                 taulell[fila][columna+3]=1
                 taulell[fila][columna+4]=1
             
    taulell=añadir_barcos(taulell,2)        
    taulell=añadir_barcos(taulell,2)
    taulell=añadir_barcos(taulell,2)
    taulell=añadir_barcos(taulell,3)             
    taulell=añadir_barcos(taulell,3)        
    taulell=añadir_barcos(taulell,3)
    taulell=añadir_barcos(taulell,4)  
    taulell=añadir_barcos(taulell,4)  
        
    return taulell
    
     # Los siguientes barcos
def añadir_barcos(taulell,tamaño):
     no_coincide=False
     while (no_coincide==False):
         # 0 o 1 de forma aleatoria
         orientacion=bool(random.getrandbits(1))
         
         fila=random.randint(0,len(taulell)-1)
         columna=random.randint(0,len(taulell)-1)
         
         
         if (orientacion==True):
             
             if(fila+tamaño in range(0,len(taulell)-1)):
                 
                 for i in range(0,tamaño):
                     
                     
                     if(taulell[fila+i][columna]==0):
                         
                         taulell[fila+i][columna]=1
                         no_coincide=True
                     else:
                         no_coincide=False
         else:
             if(columna+tamaño in range(0,len(taulell)-1)):
                 for i in range(0,tamaño):
                     
                     if(taulell[fila][columna+i]==0):
                         taulell[fila][columna+i]=1
                         no_coincide=True
                     else:
                         no_coincide=False
     return taulell


# Función que convierte el formato de fila y columna del tablero al formato del ordenador para trabajar con listas.
    
def taulell_ordinador (fila, columna):
    
    int_columna=ord(columna)-65
    int_columna=int(int_columna)
    fila=int(fila)
    
    return fila,int_columna



# Función que convierte el formato de fila y columna del ordenador al formato de la barra.
def ordinador_taullell (fila, columna):
    
    fila_modif=fila
    columna_modif=chr(columna+65)
    
    return fila_modif,columna_modif

def jugada_ordinador (taulell) :
    res=False
    
    while(res==False):
        fila=random.randint(0,len(taulell)-1)
        columna=random.choice('ABCDEFGHIJ')
        fila_modif,columna_modif=taulell_ordinador(fila,columna)
        fila_modif=int(fila_modif)
        columna_modif=int(columna_modif)
        
        if((taulell[fila_modif][columna_modif]!=2) | (taulell[fila_modif][columna_modif]!=3)):
            res=True
        
    return fila_modif,columna_modif


def tot_enfonsat (taulell):
    res=True
    for i in range(0,len(taulell)-1):
        for j in range(0,len(taulell)-1):
            if((i==1) | (j==1)):
                res=False
    return res 

def comprueba_tablon(taulell,fila,columna):
    
    int_columna=ord(columna)-65
    int_columna=int(int_columna)
    fila=int(fila)
    res=False
    
    if(taulell[fila][int_columna]==0):
        taulell[fila][int_columna]=2
        print(str(fila)+' '+str(columna) + ' Agua!')
        res=True
    elif(taulell[fila][int_columna]==1):
        taulell[fila][int_columna]=3
        print(str(fila)+' '+str(columna) +' Tocado!')
        res=True
    else:
        res=False
        
    return taulell,res
    

# juego
finalizado=False
# 1. Inicializar tableros
taulell_O=crear_taulell(10)

taulell_J=crear_taulell(10)
# 2. Llenar tablero ordenador

taulell_O=omplir_taulell_ordinador(taulell_O,30)

# 3. Rellenar tablero jugador
taulell_J=omplir_taulell_jugador(taulell_J)

print('Tablones rellenos!')
    
# 4. Iteración de jugadas. Empieza siempre el jugador
while(finalizado==False):
    res=False
    # Creamos este while por si se introduce un valor que ya haya salido
    while(res==False):
        # pedir jugada empieza jugador
        fila_jug, columna_jug= demana_jugada()
                
        # Comprobar resultado (agua/tocado) y mostrarlo por pantalla
        taulell_O,res=comprueba_tablon(taulell_O, fila_jug, columna_jug)
        

    print('Tablon del Jugador')
    visualitza_taulell(taulell_J,False)
    # Comprobar si se ha terminado el juego. Si es así mostrar un mensaje y terminar.
    
    finalizado=tot_enfonsat(taulell_O)
    
    if(finalizado==True):
        print('Fin del juego')
    # Generar jugada del ordenador
    
    
    fila_ord,columna_ord=jugada_ordinador(taulell_J)

    fila_ord_modif,columna_ord_modif = ordinador_taullell(fila_ord,columna_ord)

    # Comprobar resultado (agua / tocado) y mostrarlo por pantalla
    comprueba_tablon(taulell_J,fila_ord_modif,columna_ord_modif)
    
    
    print('Tablon del Ordenador')
    # Mostrar el tablero del ordenador actualizado (barcos ocultos)
    visualitza_taulell(taulell_O,False)
    # Comprobar si se ha terminado el juego. Si es así mostrar un mensaje y terminar
    finalizado=tot_enfonsat(taulell_J)
    
    print('¿Quieres salir?')
    if(input()=='S'):
        break
    
    




